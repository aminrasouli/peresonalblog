(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[15],{

/***/ "KTQB":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("o0o1");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("1OyB");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("vuIU");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("Ji7U");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("md7G");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("foSv");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("q1tI");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _core_theme_Layout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("mVjc");
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("ffb8");
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("vDqi");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _static_js_prismjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("DDgr");
/* harmony import */ var _static_js_prismjs__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_static_js_prismjs__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _core_classes_helper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("CxmY");
/* harmony import */ var _core_components_Link__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("+Kn8");






var __jsx = react__WEBPACK_IMPORTED_MODULE_6___default.a.createElement;

function _createSuper(Derived) { return function () { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }









var BlogPost = /*#__PURE__*/function (_Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(BlogPost, _Component);

  var _super = _createSuper(BlogPost);

  function BlogPost(props) {
    var _this;

    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(this, BlogPost);

    _this = _super.call(this, props);
    _this.state = {
      slug: '',
      data: {
        title: {
          rendered: ' '
        },
        content: {
          rendered: ' '
        },
        date: ''
      }
    };
    return _this;
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(BlogPost, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      document.querySelectorAll('pre').forEach(function (pre) {
        if (pre.className.includes('jscript')) {
          pre.className = pre.className.replace(/brush:\s*(.+?)\s*;/ig, 'language-javascript');
        } else {
          pre.className = pre.className.replace(/brush:\s*(.+?)\s*;/ig, 'language-$1 $1');
        }

        Prism.highlightElement(pre);
      });
    }
  }, {
    key: "render",
    value: function render() {
      return __jsx(_core_theme_Layout__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], null, __jsx(next_seo__WEBPACK_IMPORTED_MODULE_8__["NextSeo"], {
        title: this.props.data.title.rendered,
        titleTemplate: "\u0645\u062D\u0645\u062F\u200C\u0627\u0645\u06CC\u0646 \u0631\u0633\u0648\u0644\u06CC | %s"
      }), __jsx("section", {
        className: "intro-section"
      }, __jsx("div", {
        className: "container"
      }, __jsx("div", {
        className: "row"
      }, __jsx("div", {
        className: "col-12"
      }, __jsx("div", null, __jsx("div", {
        className: "angle-double"
      }, __jsx(_core_components_Link__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"], {
        href: "/blog"
      }, __jsx("a", null, __jsx("span", {
        className: "fa fa-angle-double-right"
      }), " "))), __jsx("div", null, __jsx("h2", {
        className: "section-title"
      }, this.props.data.title.rendered), __jsx("div", {
        className: "blog-meta"
      }, this.props.data.date && _core_classes_helper__WEBPACK_IMPORTED_MODULE_11__[/* default */ "a"].formatDate(this.props.data.date)))), __jsx("div", {
        className: "content-blog",
        dangerouslySetInnerHTML: {
          __html: this.props.data.content.rendered
        }
      }))), __jsx("hr", null))));
    }
  }], [{
    key: "getInitialProps",
    value: function getInitialProps(context) {
      var slug, response;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getInitialProps$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              slug = context.query.slug;
              _context.prev = 1;
              _context.next = 4;
              return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(axios__WEBPACK_IMPORTED_MODULE_9___default.a.get("https://rasouli.me/wp-json/wp/v2/posts?slug=".concat(slug)));

            case 4:
              response = _context.sent;
              return _context.abrupt("return", {
                data: response.data[0]
              });

            case 8:
              _context.prev = 8;
              _context.t0 = _context["catch"](1);
              console.log(_context.t0);

            case 11:
            case "end":
              return _context.stop();
          }
        }
      }, null, null, [[1, 8]], Promise);
    }
  }]);

  return BlogPost;
}(react__WEBPACK_IMPORTED_MODULE_6__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (BlogPost);

/***/ }),

/***/ "MTnK":
/***/ (function(module, exports, __webpack_require__) {


    (window.__NEXT_P=window.__NEXT_P||[]).push(["/blog/[slug]", function() {
      var mod = __webpack_require__("KTQB")
      if(false) {}
      return mod
    }]);
  

/***/ }),

/***/ "yLpj":
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || new Function("return this")();
} catch (e) {
	// This works if the window reference is available
	if (typeof window === "object") g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ })

},[["MTnK",0,2,6,8,1,4,5,3,7]]]);