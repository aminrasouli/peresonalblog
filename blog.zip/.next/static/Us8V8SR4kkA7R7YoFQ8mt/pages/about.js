(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[13],{

/***/ "Juyh":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("1OyB");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("vuIU");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("Ji7U");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("md7G");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("foSv");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("q1tI");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _core_theme_Layout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("mVjc");
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("ffb8");
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_7__);





var __jsx = react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement;

function _createSuper(Derived) { return function () { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }





var About = /*#__PURE__*/function (_Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(About, _Component);

  var _super = _createSuper(About);

  function About(props) {
    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(this, About);

    return _super.call(this, props);
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(About, [{
    key: "render",
    value: function render() {
      return __jsx(_core_theme_Layout__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], null, __jsx(next_seo__WEBPACK_IMPORTED_MODULE_7__["NextSeo"], {
        title: "\u062F\u0631\u0628\u0627\u0631\u0647 \u200C\u0645\u0646",
        titleTemplate: "\u0645\u062D\u0645\u062F\u200C\u0627\u0645\u06CC\u0646 \u0631\u0633\u0648\u0644\u06CC | %s"
      }), __jsx("section", {
        className: "intro-section"
      }, __jsx("div", {
        className: "container"
      }, __jsx("div", {
        className: "row"
      }, __jsx("div", {
        className: "col-12"
      }, __jsx("h2", {
        className: "section-title"
      }, "\u062F\u0631\u0628\u0627\u0631\u0647 \u0645\u0646"))))), __jsx("section", {
        className: "page-section"
      }, __jsx("div", {
        className: "container"
      }, __jsx("div", {
        className: "row"
      }, __jsx("div", {
        className: "col-lg-6 about-me"
      }, __jsx("div", null, __jsx("h3", null, "\u0632\u06CC\u0646 \u062F\u0648 \u0647\u0632\u0627\u0631\u0627\u0646 \u0645\u0646 \u0648 \u0645\u0627\u060C \u0627\u06CC \u0639\u062C\u0628\u0627 \u0645\u0646 \u0686\u0647 \u0645\u0646\u0645\u061F"), __jsx("br", null), __jsx("p", null, "\u0645\u0646 \u060C \u0645\u062D\u0645\u062F\u200C\u0627\u0645\u06CC\u0646 \u0631\u0633\u0648\u0644\u06CC \u06CC\u06A9 ", __jsx("a", {
        href: "https://en.wikipedia.org/wiki/Server-side_scripting"
      }, "\u062A\u0648\u0633\u0639\u0647\u200C\u062F\u0647\u0646\u062F\u0647 \u0633\u0645\u062A \u0633\u0631\u0648\u0631 (Back-end)"), "\u060C\xA0\u0622\u0634\u0646\u0627 \u0628\u0647 ", __jsx("a", {
        href: "https://en.wikipedia.org/wiki/Front-end_web_development"
      }, "\u0637\u0631\u0627\u062D\u06CC \u0648\u0628 (Front-end)"), "\xA0\u0648 \u0645\u0633\u0644\u0637 \u0628\u0647 ", __jsx("a", {
        href: "http://wordpress.org"
      }, "\u0648\u0631\u062F\u067E\u0631\u0633 "), "\u0647\u0633\u062A\u0645 .\xA0\u0628\u0647 ", __jsx("a", {
        href: "http://php.net"
      }, "php"), " \u062E\u06CC\u0644\u06CC \u0639\u0644\u0627\u0642\u0647 \u062F\u0627\u0631\u0645 \u0627\u0632 \u0628\u06CC\u0646 \u0641\u0631\u06CC\u0645\u0648\u0631\u06A9 \u0647\u0627\u06CC \u0627\u06CC\u0646 \u0632\u0628\u0627\u0646\xA0", __jsx("a", {
        href: "http://laravel.com"
      }, "\u0644\u0627\u0631\u0627\u0648\u0644\xA0"), "\u0631\u0627 \u0645\u06CC\u067E\u0633\u0646\u062F\u0645 \u0648 \u0645\u062F\u062A\u06CC \u0647\u0633\u062A \u06A9\u0647 \u062F\u0631\u06AF\u06CC\u0631 \u062C\u0627\u0648\u0627\u0627\u0633\u06A9\u0631\u06CC\u067E\u062A \u0634\u062F\u0645 \u0648 \u062F\u0631 \u062D\u0627\u0644 \u06A9\u0627\u0631 \u0628\u0627 \u0641\u0631\u06CC\u0645 \u0648\u0631\u06A9 \u0647\u0627\u06CC \u0622\u0646 \u0647\u0633\u062A\u0645.")), __jsx("div", null, __jsx("h4", null, "\u0639\u0644\u0627\u0642\u0647\u200C\u0645\u0646\u062F \u0628\u0647:"), __jsx("br", null), __jsx("ul", {
        dir: "rtl"
      }, __jsx("li", null, "\u06CC\u0627\u062F\u06AF\u06CC\u0631\u06CC \u062C\u0627\u0648\u0627 \u0627\u0633\u06A9\u0631\u06CC\u067E\u062A \u0648 \u0633\u0627\u06CC\u0632 \u0632\u0628\u0627\u0646 \u0647\u0627\u06CC \u0627\u0633\u06A9\u0631\u06CC\u067E\u062A \u0646\u0648\u06CC\u0633\u06CC"), __jsx("li", null, "\u062A\u062D\u0642\u06CC\u0642 \u0648 \u0645\u0637\u0627\u0644\u0639\u0647 \u062F\u0631 \u0645\u0648\u0631\u062F \u0634\u06CC\u0648\u0647\u200C\u0647\u0627\u06CC \u0631\u0645\u0632\u0646\u06AF\u0627\u0631\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0648 \u0645\u0628\u0627\u062D\u062B \u0627\u0645\u0646\u06CC\u062A"), __jsx("li", null, "\u0645\u0648\u0633\u06CC\u0642\u06CC \u067E\u0627\u067E \u0648 \u0631\u0627\u06A9"), __jsx("li", null, "\u0631\u0627\u0628\u0637 \u06A9\u0627\u0631\u0628\u0631\u06CC \u0648 \u062A\u062C\u0631\u0628\u0647 \u06A9\u0627\u0631\u0628\u0631\u06CC (UI/UX)"), __jsx("li", null, "\u0645\u0637\u0627\u0644\u0639\u0647 \u062F\u0631\u0628\u0627\u0631\u0647 \xA0\u0647\u0648\u0627\u0641\u0636\u0627 \u0648 \u0641\u0644\u0633\u0641\u0647"), __jsx("li", null, "\u0645\u0647\u0646\u062F\u0633\u06CC \u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631"), __jsx("li", null, "\u0642\u0647\u0648\u0647 \xA0\u2615")), __jsx("br", null)), __jsx("div", null, __jsx("h4", null, "\u0622\u0634\u0646\u0627\u06CC\u06CC:"), __jsx("br", null), __jsx("ul", {
        dir: "ltr",
        style: {
          textAlign: 'left'
        }
      }, __jsx("li", null, "PHP and Laravel"), __jsx("li", null, "Git and Github"), __jsx("li", null, "Wordpress"), __jsx("li", null, "Javascript and jQuery"), __jsx("li", null, "React and Vue"), __jsx("li", null, "NextJS and ElectronJS"), __jsx("li", null, "Linux and Unix"), __jsx("li", null, "...")))), __jsx("div", {
        className: "col-lg-5 offset-lg-1"
      }, __jsx("figure", {
        className: "pic-frame"
      }, __jsx("img", {
        src: "/static/img/about.png",
        alt: ""
      })))))));
    }
  }]);

  return About;
}(react__WEBPACK_IMPORTED_MODULE_5__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (About);

/***/ }),

/***/ "rB5V":
/***/ (function(module, exports, __webpack_require__) {


    (window.__NEXT_P=window.__NEXT_P||[]).push(["/about", function() {
      var mod = __webpack_require__("Juyh")
      if(false) {}
      return mod
    }]);
  

/***/ })

},[["rB5V",0,2,6,1,4,5,3]]]);