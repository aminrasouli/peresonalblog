(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[16],{

/***/ "ALdH":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("1OyB");
/* harmony import */ var _babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("vuIU");
/* harmony import */ var _babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("Ji7U");
/* harmony import */ var _babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("md7G");
/* harmony import */ var _babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("foSv");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("q1tI");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _core_theme_Layout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("mVjc");
/* harmony import */ var _static_css_styles_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("BhEu");
/* harmony import */ var _static_css_styles_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_static_css_styles_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("ffb8");
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_8__);





var __jsx = react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement;

function _createSuper(Derived) { return function () { var Super = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = Object(_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }






var Contact = /*#__PURE__*/function (_Component) {
  Object(_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(Contact, _Component);

  var _super = _createSuper(Contact);

  function Contact(props) {
    Object(_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(this, Contact);

    return _super.call(this, props);
  }

  Object(_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(Contact, [{
    key: "render",
    value: function render() {
      return __jsx(_core_theme_Layout__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], null, __jsx(next_seo__WEBPACK_IMPORTED_MODULE_8__["NextSeo"], {
        title: "\u062A\u0645\u0627\u0633 \u0628\u0627 \u0645\u0646",
        titleTemplate: "\u0645\u062D\u0645\u062F\u200C\u0627\u0645\u06CC\u0646 \u0631\u0633\u0648\u0644\u06CC | %s"
      }), __jsx("section", {
        className: "intro-section"
      }, __jsx("div", {
        className: "container"
      }, __jsx("div", {
        className: "row"
      }, __jsx("div", {
        className: "col-12"
      }, __jsx("h2", {
        className: "section-title"
      }, "\u062A\u0645\u0627\u0633 \u0628\u0627 \u0645\u0646"))))), __jsx("section", {
        className: "page-section"
      }, __jsx("div", {
        className: "container"
      }, __jsx("div", {
        className: "row"
      }, __jsx("div", {
        className: "col-md-6"
      }, __jsx("div", {
        className: "icon-box mb-5 mb-md-0"
      }, __jsx("div", {
        className: "icon"
      }, __jsx("h2", null, __jsx("i", {
        className: "fa fa-envelope"
      }))), __jsx("div", {
        className: "icon-box-content"
      }, __jsx("h3", null, "\u0627\u06CC\u0645\u06CC\u0644"), __jsx("p", null, "\u06CC\u0647 \u0627\u06CC\u0645\u06CC\u0644 \u0628\u0647 \u0622\u062F\u0631\u0633", __jsx("code", null, " amin@rasouli.me "), "\u0627\u0631\u0633\u0627\u0644 \u06A9\u0646\u06CC\u062F \u062A\u0627 \u0628\u06CC\u0634\u062A\u0631 \u0628\u0627 \u0647\u0645 \u062D\u0631\u0641 \u0628\u0632\u0646\u06CC\u0645."), __jsx("a", {
        href: "mailto:amin@rasouli.me"
      }, __jsx("button", {
        style: {
          margin: 0
        },
        className: "site-btn btn-line mr-4 mb-2"
      }, "\u0627\u0631\u0633\u0627\u0644 \u0627\u06CC\u0645\u06CC\u0644"))))), __jsx("div", {
        className: "col-md-6"
      }, __jsx("div", {
        className: "icon-box mb-5 mb-md-0"
      }, __jsx("div", {
        className: "icon"
      }, __jsx("h2", null, __jsx("i", {
        className: "fa fa-telegram"
      }))), __jsx("div", {
        className: "icon-box-content"
      }, __jsx("h3", null, " \u062A\u0644\u06AF\u0631\u0627\u0645"), __jsx("p", null, "\u0645\u06CC\u062A\u0648\u0646\u06CC\u062F \u0628\u0647 \u0627\u06CC\u200C\u062F\u06CC \u0645\u0646", __jsx("code", {
        dir: "ltr"
      }, " @AminDev "), "  \u067E\u06CC\u0627\u0645 \u0628\u062F\u06CC\u062F \u062A\u0627 \u0628\u0627 \u0647\u0645 \u062D\u0631\u0641 \u0628\u0632\u0646\u06CC\u0645. "), __jsx("a", {
        href: "tg://resolve?domain=amindev"
      }, __jsx("button", {
        style: {
          margin: 0
        },
        className: "site-btn btn-line mr-4 mb-2"
      }, "\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645 \u062F\u0631 \u062A\u0644\u06AF\u0631\u0627\u0645")))))))));
    }
  }]);

  return Contact;
}(react__WEBPACK_IMPORTED_MODULE_5__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (Contact);

/***/ }),

/***/ "lqnA":
/***/ (function(module, exports, __webpack_require__) {


    (window.__NEXT_P=window.__NEXT_P||[]).push(["/contact", function() {
      var mod = __webpack_require__("ALdH")
      if(false) {}
      return mod
    }]);
  

/***/ })

},[["lqnA",0,2,6,1,4,5,3]]]);