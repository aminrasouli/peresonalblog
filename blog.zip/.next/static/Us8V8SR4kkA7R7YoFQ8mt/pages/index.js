(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[17],{

/***/ "RNiq":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__("1OyB");

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/createClass.js
var createClass = __webpack_require__("vuIU");

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/inherits.js + 1 modules
var inherits = __webpack_require__("Ji7U");

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js + 1 modules
var possibleConstructorReturn = __webpack_require__("md7G");

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__("foSv");

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__("q1tI");
var react_default = /*#__PURE__*/__webpack_require__.n(react);

// EXTERNAL MODULE: ./core/theme/Layout.js + 2 modules
var Layout = __webpack_require__("mVjc");

// EXTERNAL MODULE: ./node_modules/next-seo/lib/index.js
var lib = __webpack_require__("ffb8");

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__("YFqc");

// CONCATENATED MODULE: ./core/components/CardProject.js





var __jsx = react_default.a.createElement;

function _createSuper(Derived) { return function () { var Super = Object(getPrototypeOf["a" /* default */])(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = Object(getPrototypeOf["a" /* default */])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(possibleConstructorReturn["a" /* default */])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }




var CardProject_CardProject = /*#__PURE__*/function (_Component) {
  Object(inherits["a" /* default */])(CardProject, _Component);

  var _super = _createSuper(CardProject);

  function CardProject(props) {
    Object(classCallCheck["a" /* default */])(this, CardProject);

    return _super.call(this, props);
  }

  Object(createClass["a" /* default */])(CardProject, [{
    key: "render",
    value: function render() {
      return __jsx("div", {
        className: "col-md-4"
      }, __jsx("div", {
        className: "card mb-4 shadow-sm card-project"
      }, __jsx("div", {
        className: "card-project-img-mask"
      }, __jsx("img", {
        className: "card-project-image",
        src: this.props.img
      })), __jsx("div", {
        className: "card-body card-project-body"
      }, __jsx("h4", {
        className: "card-project-title"
      }, this.props.title), __jsx("div", {
        className: "card-project-details"
      }, __jsx("time", {
        className: "card-project-time"
      }, this.props.date), __jsx("br", null), __jsx("span", {
        className: "card-project-text"
      }, this.props.details)), __jsx("br", null), __jsx("div", {
        className: "pull-left"
      }, __jsx("a", {
        href: this.props.href
      }, __jsx("button", {
        type: "button",
        className: "btn btn-sm btn-outline-secondary card-project-button"
      }, "\u0628\u06CC\u0634\u062A\u0631"))))));
    }
  }]);

  return CardProject;
}(react["Component"]);

/* harmony default export */ var components_CardProject = (CardProject_CardProject);
// CONCATENATED MODULE: ./core/components/Project.js





var Project_jsx = react_default.a.createElement;

function Project_createSuper(Derived) { return function () { var Super = Object(getPrototypeOf["a" /* default */])(Derived), result; if (Project_isNativeReflectConstruct()) { var NewTarget = Object(getPrototypeOf["a" /* default */])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(possibleConstructorReturn["a" /* default */])(this, result); }; }

function Project_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }





var Project_Project = /*#__PURE__*/function (_Component) {
  Object(inherits["a" /* default */])(Project, _Component);

  var _super = Project_createSuper(Project);

  function Project(props) {
    Object(classCallCheck["a" /* default */])(this, Project);

    return _super.call(this, props);
  }

  Object(createClass["a" /* default */])(Project, [{
    key: "render",
    value: function render() {
      return Project_jsx("section", {
        className: "portfolio-section"
      }, Project_jsx("div", {
        className: "container p-md-0 "
      }, Project_jsx("h3", {
        className: "project-title"
      }, "\u067E\u0631\u0648\u0698\u0647 \u0647\u0627"), Project_jsx("hr", null), Project_jsx("div", {
        className: "row portfolios-area"
      }, Project_jsx(components_CardProject, {
        title: "\u0646\u0631\u0645\u200C\u0627\u0641\u0632\u0627\u0631 \u0645\u062F\u06CC\u0631\u06CC\u062A \u0633\u0641\u0627\u0631\u0634\u0627\u062A \u0648\u0648\u06A9\u0627\u0645\u0631\u0633",
        img: "/static/img/project/woodesktop.png",
        date: "\u0632\u0645\u0633\u062A\u0627\u0646 \u06F9\u06F7",
        details: "#ElectronJS,ReactJs,BootStrap,Woocommerce",
        href: "http://atbox.io/mramin/projects/NyDrl"
      }), Project_jsx(components_CardProject, {
        title: "\u0648\u06CC\u062A\u0631\u06CC\u0646 \u0633\u0627\u06CC\u062A \u0627\u06AF\u0647\u06CC \u0648 \u0646\u06CC\u0627\u0632\u0645\u0646\u062F\u06CC\u200C\u0647\u0627",
        img: "/static/img/project/vitrin.png",
        date: "\u062A\u0627\u0628\u0633\u062A\u0627\u0646 \u06F9\u06F7",
        details: "#Laravel Framework,PHP,Bootstrap,Javascript,jQuery",
        href: "http://atbox.io/mramin/projects/K7Llr"
      }), Project_jsx(components_CardProject, {
        title: "\u0631\u0627\u06CC\u0627\u062A\u0627\u0631 \u0645\u062C\u0644\u0647 \u062A\u0641\u0631\u06CC\u062D\u06CC \u0633\u0631\u06AF\u0631\u0645\u06CC",
        img: "/static/img/project/rayatar.png",
        date: "\u0628\u0647\u0627\u0631 \u06F9\u06F3",
        details: "#WordPress,HTML,CSS,Javascript,jQuery",
        href: "#"
      }))));
    }
  }]);

  return Project;
}(react["Component"]);

/* harmony default export */ var components_Project = (Project_Project);
// EXTERNAL MODULE: ./core/components/SocialLink.js
var SocialLink = __webpack_require__("aOVu");

// EXTERNAL MODULE: ./core/classes/helper.js
var helper = __webpack_require__("CxmY");

// CONCATENATED MODULE: ./pages/index.js





var pages_jsx = react_default.a.createElement;

function pages_createSuper(Derived) { return function () { var Super = Object(getPrototypeOf["a" /* default */])(Derived), result; if (pages_isNativeReflectConstruct()) { var NewTarget = Object(getPrototypeOf["a" /* default */])(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return Object(possibleConstructorReturn["a" /* default */])(this, result); }; }

function pages_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }








var pages_Index = /*#__PURE__*/function (_Component) {
  Object(inherits["a" /* default */])(Index, _Component);

  var _super = pages_createSuper(Index);

  function Index() {
    Object(classCallCheck["a" /* default */])(this, Index);

    return _super.apply(this, arguments);
  }

  Object(createClass["a" /* default */])(Index, [{
    key: "render",
    value: function render() {
      return pages_jsx(Layout["a" /* default */], null, pages_jsx(lib["NextSeo"], {
        title: "\u0635\u0641\u062D\u0647 \u0627\u0635\u0644\u06CC",
        titleTemplate: "\u0645\u062D\u0645\u062F\u200C\u0627\u0645\u06CC\u0646 \u0631\u0633\u0648\u0644\u06CC | %s"
      }), pages_jsx("section", {
        className: "intro-section"
      }, pages_jsx("div", {
        className: "container text-center"
      }, pages_jsx("div", {
        className: "row"
      }, pages_jsx("div", {
        className: "col-xl-10 offset-xl-1"
      }, pages_jsx("img", {
        className: "avatar-intro-section",
        src: "/static/img/newAvatar.png",
        alt: "avatar"
      }), pages_jsx("h2", {
        className: "section-title",
        style: {
          fontWeight: 300
        }
      }, "Software Developer With Focus On", pages_jsx("br", null), pages_jsx("span", null, "Full Stack Development")))))), pages_jsx(SocialLink["a" /* default */], {
        isShow: helper["a" /* default */].isRoute('/')
      }), pages_jsx(components_Project, null));
    }
  }]);

  return Index;
}(react["Component"]);

/* harmony default export */ var pages = __webpack_exports__["default"] = (pages_Index);

/***/ }),

/***/ "vlRD":
/***/ (function(module, exports, __webpack_require__) {


    (window.__NEXT_P=window.__NEXT_P||[]).push(["/", function() {
      var mod = __webpack_require__("RNiq")
      if(false) {}
      return mod
    }]);
  

/***/ })

},[["vlRD",0,2,6,1,4,5,3]]]);